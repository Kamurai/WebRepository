<?php
	include './Layout.php';
	
    $Page = 1;
    $Level = 0;
    $Section = 0;
    #Overall body
	WriteLayout($Page, $Level, $Section);
    
?>