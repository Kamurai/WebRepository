<?php
	include './Layout.php';
	
    $Page =7;
    $Level = 1;
    $Section = 2;
    #Overall body
	WriteLayout($Page, $Level, $Section);
    
?>