<?php
	include './Layout.php';
	
    $Page = 0;
    $Level = 2;
    $Section = 2;
    #Overall body
	WriteLayout($Page, $Level, $Section);
    
	$title = "Gynowars";
	$centerHeader = "Gynowars";
	$centerContent = "
						This section is dedicated to projects centered in the Gynowars universe.
					";
	$GDR = "<a href='../Downloads/GDR.zip'>You can download my Games Development Report here.</a></br>";
	$winrar = "<a href='../Downloads/wrar371.exe'>You may need WinRar to open zip files from this site.</a></br>";

	$infoContent = "This is written with PHP.<br><br>
					Other versions of this page are here:<br>
					<a href=\"http://htkb.dyndns.org/Section2/Section1/index.html\">HTML</a><br>
					<a href=\"http://htkb.dyndns.org/Javascript/Section2/Section1/index.html\">HTML Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASP/Section2/Section1/index.asp\">ASP Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASPNET/Section2/Section1/index.aspx\">ASP.NET Javascript</a><br>
					<a href=\"http://htkb.dyndns.org/Section2/Section1/index.shtml\">Perl</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSPApplication/Section2/Section1/index.jsp\">JSP</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSFApplication/Section2/Section1/index.xhtml\">JSF</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebApplication/Section2/Section1/index.cshtml\">ASP.NET Web App</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebForm/Section2/Section1/index.aspx\">ASP.NET Webform</a><br>
					<a href=\"http://htkb.dyndns.org:81/MVC/Main/Section2/Section1/index\">ASP.NET MVC App</a><br>
					<a href=\"http://htkb.dyndns.org/SSI/Section2/Section1/index.html\">Apache SSI</a><br>
				";
	

	#Overall body
	include $style.'Layout.php';
?>