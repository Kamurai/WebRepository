<?php
	include './Layout.php';
	
    $Page = 0;
    $Level = 15;
    $Section = 2;
    #Overall body
	WriteLayout($Page, $Level, $Section);
    
?>