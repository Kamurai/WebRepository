<?php
	include './Layout.php';
	
    $Page = 1;
    $Level = 3;
    $Section = 2;
    #Overall body
	WriteLayout($Page, $Level, $Section);
    
	$title = "Nine Card";
	$centerHeader = "Nine Card";
	$centerContent = "
						Nine Card is a Tactical card game played through the Elvia Empire.</br>
					";
	$GDR = "";
	$winrar = "";

	$infoContent = "This is written with PHP.<br><br>
					Other versions of this page are here:<br>
					<a href=\"http://htkb.dyndns.org/Minecraft.html\">HTML</a><br>
					<a href=\"http://htkb.dyndns.org/Javascript/Minecraft.html\">HTML Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASP/Minecraft.asp\">ASP Javascript</a><br>
					<a href=\"http://htkb.dyndns.org:81/ASPNET/Minecraft.aspx\">ASP.NET Javascript</a><br>
					<a href=\"http://htkb.dyndns.org/Minecraft.shtml\">Perl</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSPApplication/Minecraft.jsp\">JSP</a><br>
					<a href=\"http://htkb.dyndns.org:8080/JSFApplication/Minecraft.xhtml\">JSF</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebApplication/Minecraft.cshtml\">ASP.NET Web App</a><br>
					<a href=\"http://htkb.dyndns.org:81/WebForm/Minecraft.aspx\">ASP.NET Webform</a><br>
					<a href=\"http://htkb.dyndns.org:81/MVC/Main/Minecraft\">ASP.NET MVC App</a><br>
					<a href=\"http://htkb.dyndns.org/SSI/Minecraft.html\">Apache SSI</a><br>
				";
	

	#Overall body
	include $style.'Layout.php';
?>