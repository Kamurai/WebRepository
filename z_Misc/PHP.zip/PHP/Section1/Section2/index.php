<?php
	include './Layout.php';
	
    $Page = 0;
    $Level = 2;
    $Section = 1;
    #Overall body
	WriteLayout($Page, $Level, $Section);
    
?>