<?php
echo "
		<a class=\"navlinkA\" href='".$path."Section1/Project1.html'>Basic HTML</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Project1.php'>PHP</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section2/Index.php'>Java Script</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Project3.shtml'>Perl</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section4/Index.php'>Java</a></br></br>
			<a class=\"navlinkB\" href='http://htkb.dyndns.org:8080/JSPApplication/Section1/Section4/Project1.jsp'>JSP Programming</a></br></br>
			<a class=\"navlinkB\" href='http://htkb.dyndns.org:8080/JSFApplication/Section1/Section4/Project2.xhtml'>JSF Programming</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section5/Index.php'>ASP.Net</a></br></br>
		<a class=\"navlinkA\" href='".$path."Section1/Section6/Index.php'>Databases</a></br></br>
		<a class=\"navlinkA\" href='http://htkb.dyndns.org/SSI/Section1/index.html'>Apache SSI</a></br></br>
	";
?>