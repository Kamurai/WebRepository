<?php
	include './Layout.php';
	
    $Page = 1;
    $Level = 1;
    $Section = 1;
    #Overall body
	WriteLayout($Page, $Level, $Section);
	
?>